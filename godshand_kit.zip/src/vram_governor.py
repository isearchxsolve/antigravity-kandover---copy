#!/usr/bin/env python3
"""vram_governor.py -- Pre-shot VRAM probe + parameter resolver.

Prevents OOM on Kaggle 2xT4 by polling nvidia-smi before every render and
picking parameters that fit the available memory. Three regimes:

    PLENTY  (>= 14 GB free): full quality, no offload, fp16 weights
    TIGHT   (10-14 GB)      : fp16 weights, attention slicing, VAE tiling
    DANGER  (< 10 GB)       : CPU offload model parts, fp8 if available,
                              reduce steps, shorter clip length

Pure stdlib -- no torch import here so it loads instantly even on cold start.
"""
import os, subprocess, json, time

QUERY_RETRY = 3
QUERY_DELAY = 1.5
SAFE_RESERVE_MB = 1500

REGIME_FULL = "plenty"
REGIME_TIGHT = "tight"
REGIME_DANGER = "danger"


def _query_smi():
    """Return list of {index, name, total_mb, used_mb, free_mb, temp_c, util_pct}."""
    out = []
    try:
        r = subprocess.run(
            ["nvidia-smi",
             "--query-gpu=index,name,memory.total,memory.used,memory.free,"
             "temperature.gpu,utilization.gpu",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=10,
        )
        if r.returncode != 0:
            return out
        for line in r.stdout.strip().splitlines():
            parts = [p.strip() for p in line.split(",")]
            if len(parts) < 7:
                continue
            try:
                out.append({
                    "index": int(parts[0]),
                    "name": parts[1],
                    "total_mb": int(parts[2]),
                    "used_mb": int(parts[3]),
                    "free_mb": int(parts[4]),
                    "temp_c": int(parts[5]),
                    "util_pct": int(parts[6]),
                })
            except (ValueError, IndexError):
                continue
    except Exception:
        pass
    return out


def _query_smi_robust():
    last = None
    for _ in range(QUERY_RETRY):
        gpus = _query_smi()
        if gpus:
            return gpus
        last = "empty"
        time.sleep(QUERY_DELAY)
    return []


def free_mb(gpu_index=0):
    """Free VRAM on a specific GPU, in MB. Returns 0 on any failure."""
    for g in _query_smi_robust():
        if g["index"] == gpu_index:
            return g["free_mb"]
    return 0


def probe_all():
    """Return full GPU list with free_mb, temp, util. Empty list if no GPUs."""
    return _query_smi_robust()


def pick_regime(free):
    """Resolve a regime string from free VRAM (MB)."""
    if free >= 14 * 1024:
        return REGIME_FULL
    if free >= 10 * 1024:
        return REGIME_TIGHT
    return REGIME_DANGER


def resolve_params(cfg, gpu_index=0, shot=None):
    """Mutate-and-return a per-shot param dict that fits the available VRAM.

    Honors the configured width/height/steps/seconds but downgrades memory-heavy
    knobs (offload level, attention slicing, VAE tile size) when VRAM is tight.
    Returns a dict with keys: regime, free_mb, width, height, steps, seconds,
    offload_level, attention_slicing, vae_tiling, vae_tile_size, fp8, notes.
    """
    free = free_mb(gpu_index)
    regime = pick_regime(free)
    base_w = int((shot or {}).get("width", cfg.get("width", 1280)))
    base_h = int((shot or {}).get("height", cfg.get("height", 704)))
    base_steps = int((shot or {}).get("steps", cfg.get("steps", 30)))
    base_seconds = float((shot or {}).get("dur", cfg.get("max_clip_seconds", 5)))
    out = {
        "regime": regime,
        "free_mb": free,
        "gpu_index": gpu_index,
        "width": base_w,
        "height": base_h,
        "steps": base_steps,
        "seconds": base_seconds,
        "offload_level": "none",
        "attention_slicing": False,
        "vae_tiling": False,
        "vae_tile_size": 256,
        "fp8": False,
        "notes": [],
    }
    if regime == REGIME_FULL:
        out["notes"].append(">=14GB free: full quality")
    elif regime == REGIME_TIGHT:
        out["attention_slicing"] = True
        out["vae_tiling"] = True
        out["vae_tile_size"] = 512
        out["notes"].append("10-14GB free: attention slicing + VAE tiling on")
    else:
        out["attention_slicing"] = True
        out["vae_tiling"] = True
        out["vae_tile_size"] = 256
        out["offload_level"] = "model"
        out["fp8"] = True
        out["steps"] = max(12, base_steps - 8)
        out["seconds"] = min(base_seconds, 4.0)
        out["notes"].append("<10GB free: cpu offload + fp8 + reduced steps/seconds")
    return out


def wait_for_vram(min_free_mb, gpu_index=0, timeout_sec=300, poll_sec=5.0):
    """Block until `min_free_mb` is available on `gpu_index`. Returns final free_mb."""
    t0 = time.time()
    while time.time() - t0 < timeout_sec:
        free = free_mb(gpu_index)
        if free >= min_free_mb:
            return free
        time.sleep(poll_sec)
    return free_mb(gpu_index)


def safety_margin_mb():
    return int(os.environ.get("KIT_VRAM_SAFETY_MB", str(SAFE_RESERVE_MB)))


if __name__ == "__main__":
    gpus = probe_all()
    if not gpus:
        print("[vram_governor] no GPUs visible -- skip.")
    else:
        print(json.dumps(gpus, indent=2))
        for g in gpus:
            print(f"[vram_governor] GPU {g['index']} ({g['name']}): "
                  f"free={g['free_mb']}MB temp={g['temp_c']}C util={g['util_pct']}% "
                  f"regime={pick_regime(g['free_mb'])}")
