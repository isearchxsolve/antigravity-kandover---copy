#!/usr/bin/env python3
"""gpu_scheduler.py -- Staggered 2xT4 thermal-aware shot scheduler.

Two T4s sitting side-by-side on a Kaggle node thermal-couple. Running both at
100% simultaneously causes one to throttle the other. This module:

  * Round-robin assigns each shot to the coolest free GPU.
  * Records a per-GPU "last finished at" timestamp and refuses to re-dispatch
    to the same GPU within MIN_GAP_SEC (gives the heatsink time to shed).
  * Detects throttling (sustained 100% util + rising temp) and sleeps until
    the GPU drops below THROTTLE_TEMP_C.
  * Falls back to a single-GPU pipeline on instances with one GPU.

Pure stdlib. No torch / nvidia-ml-py dependency.
"""
import os, time
import vram_governor as vg

MIN_GAP_SEC = float(os.environ.get("KIT_GPU_GAP_SEC", "12"))
THROTTLE_TEMP_C = int(os.environ.get("KIT_GPU_THROTTLE_TEMP_C", "83"))
TEMP_GREEN_C = int(os.environ.get("KIT_GPU_TEMP_GREEN_C", "76"))
COOLDOWN_POLL_SEC = float(os.environ.get("KIT_GPU_COOLDOWN_POLL_SEC", "3"))
COOLDOWN_TIMEOUT_SEC = float(os.environ.get("KIT_GPU_COOLDOWN_TIMEOUT_SEC", "240"))


class _GpuState:
    __slots__ = ("last_finish", "shot_count")

    def __init__(self):
        self.last_finish = 0.0
        self.shot_count = 0


class Scheduler:
    def __init__(self):
        gpus = vg.probe_all()
        if not gpus:
            self._n = 0
            self._states = []
            return
        self._n = len(gpus)
        self._states = [_GpuState() for _ in gpus]
        self._rr_index = 0
        print(f"[gpu_scheduler] {self._n} GPU(s) visible: "
              + ", ".join(f"GPU{g['index']} {g['name']}" for g in gpus))

    @property
    def gpu_count(self):
        return self._n

    def _cooldown(self, idx):
        """Block until GPU `idx` is below throttle temperature and the minimum
        inter-shot gap has elapsed since the last shot on this GPU."""
        deadline = time.time() + COOLDOWN_TIMEOUT_SEC
        s = self._states[idx]
        while True:
            now = time.time()
            gap_ok = (now - s.last_finish) >= MIN_GAP_SEC
            gpus = vg.probe_all()
            cur = next((g for g in gpus if g["index"] == idx), None)
            temp_ok = (cur is None) or (cur["temp_c"] <= THROTTLE_TEMP_C)
            if gap_ok and temp_ok:
                return
            if now > deadline:
                print(f"[gpu_scheduler] cooldown timeout on GPU {idx}; proceeding.")
                return
            time.sleep(COOLDOWN_POLL_SEC)

    def pick(self):
        """Pick a GPU for the next shot. Always returns a valid GPU index
        (or 0 in single-GPU mode). Performs thermal cooldown if needed."""
        if self._n == 0:
            return 0
        if self._n == 1:
            self._cooldown(0)
            return 0
        for _ in range(self._n):
            idx = self._rr_index % self._n
            self._rr_index += 1
            self._cooldown(idx)
            return idx
        return self._rr_index % self._n

    def finish(self, idx):
        """Mark a shot as finished on `idx`. Updates last_finish timestamp."""
        if self._n == 0:
            return
        if 0 <= idx < self._n:
            self._states[idx].last_finish = time.time()
            self._states[idx].shot_count += 1

    def summary(self):
        """Human-readable per-GPU stats for telemetry dump."""
        if self._n == 0:
            return "[gpu_scheduler] no GPUs"
        gpus = vg.probe_all()
        lines = []
        for i in range(self._n):
            cur = next((g for g in gpus if g["index"] == i), None)
            s = self._states[i]
            if cur:
                lines.append(f"GPU {i}: {cur['free_mb']}MB free, "
                             f"{cur['temp_c']}C, util {cur['util_pct']}%, "
                             f"shots done={s.shot_count}")
            else:
                lines.append(f"GPU {i}: (no telemetry), shots done={s.shot_count}")
        return "\n".join(lines)


if __name__ == "__main__":
    s = Scheduler()
    print(s.summary())
